#ifndef STDDEV_H
#define STDDEV_H
  void stats (float *data, int n);
#endif
