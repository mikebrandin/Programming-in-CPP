#include <stdio.h>

int main(){

printf("This is my first C++ program!\nI love Linux!\n");


  return 0;
}
